package ru.loko.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val red = Color.rgb(205, 18, 42)
    private val black = Color.rgb(10, 10, 14)
    private val white = Color.WHITE
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private var apps: List<android.content.pm.ResolveInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        window.decorView.systemUiVisibility = 0
        buildUi()
        loadApps("")
    }

    private fun bg(color: Int, radius: Float = 22f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 28, 18, 12)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(28, 5, 12), black, Color.rgb(30, 8, 12))
            )
        }
        val brand = TextView(this).apply {
            text = "🚂  ЛОКОМОТИВ"
            textSize = 16f; setTextColor(red); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 42))

        val clock = TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 54f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        }
        root.addView(clock, LinearLayout.LayoutParams(-1, 78))

        val subtitle = TextView(this).apply {
            text = "ЯРОСЛАВЛЬ  •  ВПЕРЁД, ЛОКО!"
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 28))

        val hero = TextView(this).apply {
            text = "47     70     87\n\nХОККЕЙНЫЙ ГОРОД"
            textSize = 24f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = bg(Color.rgb(65, 8, 20), 26f)
        }
        val heroLp = LinearLayout.LayoutParams(-1, 142); heroLp.setMargins(0, 12, 0, 14)
        root.addView(hero, heroLp)

        search = EditText(this).apply {
            hint = "Поиск приложений"
            setHintTextColor(Color.LTGRAY); setTextColor(white); textSize = 15f
            setSingleLine(true); setPadding(16, 8, 16, 8)
            background = bg(Color.rgb(38, 38, 44), 18f)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { loadApps(s?.toString() ?: "") }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 48))
        val heading = TextView(this).apply {
            text = "ПРИЛОЖЕНИЯ"; setTextColor(red); textSize = 12f
            typeface = Typeface.DEFAULT_BOLD; setPadding(4, 18, 0, 8)
        }
        root.addView(heading)
        grid = GridLayout(this).apply { columnCount = 4 }
        val scroll = ScrollView(this)
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply {
            text = "ЧЁРНЫЙ • КРАСНЫЙ • БЕЛЫЙ"
            setTextColor(Color.GRAY); textSize = 10f; gravity = Gravity.CENTER
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, 30))
        setContentView(root)
    }

    private fun loadApps(filter: String) {
        if (!::grid.isInitialized) return
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .filter { it.loadLabel(pm).toString().contains(filter, true) }
        grid.removeAllViews()
        apps.forEach { info ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(4, 10, 4, 10)
                isClickable = true
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(pm))
                background = bg(Color.rgb(34, 34, 40), 20f)
                setPadding(13, 13, 13, 13)
            }
            item.addView(icon, LinearLayout.LayoutParams(58, 58))
            val label = TextView(this).apply {
                text = info.loadLabel(pm); setTextColor(white); textSize = 10f
                gravity = Gravity.CENTER; maxLines = 2
            }
            val lp = LinearLayout.LayoutParams(-1, 34); lp.topMargin = 5
            item.addView(label, lp)
            val cell = GridLayout.LayoutParams().apply {
                width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            grid.addView(item, cell)
        }
    }
}
